$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
function Run-CMake([string[]]$Arguments) {
 & cmake @Arguments
 if ($LASTEXITCODE -ne 0) { throw "CMake failed with exit code $LASTEXITCODE" }
}
Run-CMake -Arguments @('-S','.', '-B','build-win','-A','x64')
Run-CMake -Arguments @('--build','build-win','--config','Release','--parallel','2')
& .\build-win\Release\engine_tests.exe
if ($LASTEXITCODE -ne 0) { throw 'DSP tests failed' }
Write-Host 'Built. Copy build-win\PrinceMix_artefacts\Release\VST3\PrinceMix.vst3 to C:\Program Files\Common Files\VST3, then rescan plugins in Audition.'
