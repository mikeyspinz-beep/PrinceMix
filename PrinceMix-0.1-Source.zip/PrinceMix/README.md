# PrinceMix 0.1 alpha

An Adobe Audition-compatible plugin project for mixing aligned vocal stems over a beat and mastering stereo audio. Runs locally. No account, API key, subscription service, or audio upload.

**This package contains source and build scripts, not a precompiled Mac or Windows plugin.** The DSP tests and JUCE-facing source syntax were checked on Linux. Audition loading, macOS/Windows builds, listening tests, and native UI operation still need verification. This is an initial alpha, not a finished commercial automatic mixing system.

## Build and install on Mac

1. Install Apple's Command Line Tools (`xcode-select --install` in Terminal) if needed.
2. Install CMake from https://cmake.org/download/ into Applications, or use an existing CMake installation.
3. Extract this entire folder. Quit Audition. Double-click `Build-Mac.command`. If macOS does not execute it, open Terminal, type `bash `, drag the file into Terminal, and press Return.
4. The script downloads the pinned JUCE 8.0.6 dependency, builds for your Mac's current architecture, runs DSP tests, signs locally, and installs VST3 and AU versions into your user's plugin folders. Existing PrinceMix copies are backed up under `~/Library/Application Support/PrinceMix/Backups/`.
5. Restart Audition. Open **Effects > Audio Plug-In Manager**, scan, and enable PrinceMix. Add **one** PrinceMix instance to your master track's Effects Rack.

The standalone app is also built and shown in Finder. Use its audio settings to select your output device and sample rate. Its external audio input is unnecessary for stem rendering; leave input muted if you do not need it.

This is a local development build, not a notarized installer. macOS 11 or newer is the configured minimum; the JUCE/toolchain requirements also apply. Build on the same architecture as Audition (native Apple Silicon or Intel).

## Windows

Install Visual Studio 2022 with Desktop development with C++ and CMake 3.22 or newer. Run `Build-Windows.ps1` in PowerShell. Copy the resulting `PrinceMix.vst3` bundle to `C:\Program Files\Common Files\VST3`, then scan in Audition. Building and installing on Windows have not been tested here.

## Auto mix and master your vocals and beat

1. In Audition, export each track separately as a mono or stereo WAV/AIFF, all at the **same sample rate and starting at the same timeline time**, including leading silence. Bypass existing track and master effects for dry vocal stems. Avoid exporting several overlapping versions of the same part.
2. Open PrinceMix. Select **Add stems**. The first file defaults to Beat; **verify every role**. Use Lead, Double, Harmony, or Ad-lib for the other files. Up to 12 stems are supported.
3. Adjust Vocal, Warmth, Brightness, Space, Target RMS, and Ceiling. Click **Auto mix + master**.
4. **Preview master** replaces this plugin's output while preview plays. Host playback/audio processing must be running. Preview requires the host/device sample rate to match the stems. Stop preview before bouncing the Audition session. Preview bypasses this plugin's live effects, but effects after PrinceMix in your host still apply.
5. **Export WAVs** creates a new timestamped folder containing `Mix.wav`, `Master.wav`, and `Processing-report.txt`. Audio is 24-bit stereo WAV at the original stem sample rate. Each export gets a new folder; source stems are untouched.
6. Import the resulting WAV into Audition to listen and make revisions. Do not run `Master.wav` through the live mastering chain again unless you intentionally want extra processing.

Stem selections and renders are temporary and are not saved with your Audition session. Plugin knob settings are saved with the host. Export your results before closing the plugin window. Changing settings after a render requires rendering again; automation does not retrospectively update a rendered preview.

### What the stem engine does

- Measures active audio levels, reducing the influence of gaps.
- Normalizes vocal input into a useful processing range with bounded gain.
- Applies an 85 Hz high-pass filter, low-mid EQ, brightness EQ, stereo-linked compression, and simple high-frequency de-essing to vocals.
- Adds subtle, fixed stereo delay taps via Space (not a full reverb or tempo-synced delay).
- Balances files by assigned roles and lowers supporting layers.
- Makes an unmastered mix with at least 6 dB of sample-peak headroom.
- Applies bounded gain toward the selected active RMS target, then a stereo-linked lookahead sample-peak limiter. Offline export compensates the limiter delay.

The engine uses fixed, transparent DSP rules. It does not identify genre, remove room noise, align takes, tune pitch, separate a mixed song, or control Audition faders. Multiple lead files are treated as simultaneous layers; split sequential takes should be consolidated into one stem for better balancing. The mixer does not yet duck the beat or apply arrangement-aware automation.

## Live mastering in Audition

For an already mixed song, insert PrinceMix on the master track. Warmth, Brightness, Live Gain, and Ceiling affect incoming audio. Vocal and Space apply only to the stem renderer. Target controls the stem target and the Learn calculation.

Click **Learn live master**, then play a representative loud section. After 10 seconds of audible samples, the plugin sets Live Gain to a bounded RMS-based estimate. Silence pauses collection. Click again to cancel. The live chain applies a 25 Hz high-pass, tone EQ, gain, and lookahead limiting; it reports its 3 ms latency to the host.

Start with conservative gain. This first version measures RMS and sample peaks, **not integrated LUFS or true peak**. A limiter can prevent the target from being reached. The default -1.5 dBFS sample ceiling is headroom, not a guarantee against intersample overs. Reports state the actual achieved levels. Use Audition's meters and your ears to assess the result.

## Limits

Files must share a sample rate (22.05–192 kHz) and have one or two channels. Each file is limited to 10 minutes; the total session is limited to the sample count equivalent of 30 stem-minutes at 48 kHz. Whole files are held in memory. The renderer pads 250 ms for ambience. Render work runs in a worker thread; closing the editor during rendering waits for the current render to finish.

No actual user song was available for listening evaluation. Automated tests establish signal integrity, not mix quality. De-essing and level targets should be evaluated on your recordings before broader use.

## Developer verification

Dependency-free tests:

```sh
cmake -S . -B build-tests -DPRINCEMIX_ENGINE_ONLY=ON
cmake --build build-tests
ctest --test-dir build-tests --output-on-failure
```

Or use `c++ -std=c++17 -O2 tests/engine_tests.cpp -o engine_tests && ./engine_tests`.

A local JUCE checkout can be supplied with `-DJUCE_PATH=/absolute/path/to/JUCE`. The normal build downloads JUCE pinned to commit `51a8a6d7aeae7326956d747737ccf1575e61e209` (8.0.6).

Original PrinceMix source is MIT licensed; JUCE has its own AGPL/commercial licensing terms at https://juce.com/legal/juce-8-licence/ . Review those terms before distributing a closed-source product.

Official host reference: https://helpx.adobe.com/ca/audition/desktop/applying-effects/adding-third-party-plug-ins.html

## Automated Mac build

The included `.github/workflows/build-mac.yml` builds universal Apple Silicon and Intel VST3, AU, and standalone binaries on GitHub's macOS runner. It runs the engine tests and Apple's AU validator, ad-hoc signs the binaries, and uploads a ZIP with `Install-Mac.command`. This workflow is prepared but has not yet run. Put the contents of this project folder at the repository root. It triggers on relevant pushes to `main` or `princemix/**`, or manually through Actions. It needs no signing secrets; outputs are development builds, not notarized releases.
