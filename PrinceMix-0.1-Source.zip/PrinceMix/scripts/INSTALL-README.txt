PRINCEMIX 0.1 ALPHA — MAC DEVELOPMENT BUILD

Quit Audition, then run Install-Mac.command to install the VST3 and AU into your user plugin folders. Existing PrinceMix installations are backed up. No administrator password is required. If the script does not execute, run it via bash in Terminal.

Restart Audition, open Effects > Audio Plug-In Manager, scan, and enable PrinceMix. Add it to the master track's Effects Rack. You can also launch PrinceMix.app directly.

This development build is ad-hoc signed, not notarized by Apple. macOS may require approval through its normal security interface.

Load WAV or AIFF stems exported from the same timeline start and at the same sample rate. Assign each role, run Auto mix + master, then export. Each export includes Mix.wav, Master.wav, and a report. Stem files and rendered audio are temporary inside the plugin; export before closing its window.

For live mastering, play a representative section and click Learn live master. It measures 10 seconds of audible input and adjusts the gain. Tone, Live Gain, and Ceiling control the live chain.

RMS-based processing; not LUFS or true-peak mastering. No stem separation, tuning, or automatic control of Audition faders. This is an alpha and still needs listening and host testing on your system.
