#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
trap 'echo "Installation stopped. Copy the error above for help."; read -r -p "Press Return..."' ERR
PM_STAMP="$(date +%Y%m%d-%H%M%S)"
for PM_PAIR in 'PrinceMix.vst3|VST3' 'PrinceMix.component|Components'; do
 IFS='|' read -r PM_NAME PM_FOLDER <<< "$PM_PAIR"
 test -d "$PM_NAME"
 PM_DEST="$HOME/Library/Audio/Plug-Ins/$PM_FOLDER"
 mkdir -p "$PM_DEST"
 if [ -e "$PM_DEST/$PM_NAME" ]; then
  mkdir -p "$HOME/Library/Application Support/PrinceMix/Backups/$PM_STAMP"
  mv "$PM_DEST/$PM_NAME" "$HOME/Library/Application Support/PrinceMix/Backups/$PM_STAMP/$PM_NAME"
 fi
 ditto "$PM_NAME" "$PM_DEST/$PM_NAME"
done
echo 'PrinceMix installed. Restart Audition, then Effects > Audio Plug-In Manager > Scan.'
echo 'This is a locally signed alpha, not an Apple-notarized release.'
read -r -p 'Press Return to close...'
