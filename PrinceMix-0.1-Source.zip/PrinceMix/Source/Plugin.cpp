#include <juce_audio_utils/juce_audio_utils.h>
#include "Engine.h"
#include <thread>
#include <atomic>
#include <mutex>

using namespace juce;
class PrinceEditor;
class PrinceProcessor final : public AudioProcessor {
public:
 AudioProcessorValueTreeState state;
 pm::Limiter limiter;
 std::array<pm::Biquad,2> hp,body,air;
 double rate=44100;
 SmoothedValue<float,ValueSmoothingTypes::Linear> smoothDrive;
 std::atomic<bool> learning{false}, learned{false};
 std::atomic<float> learnedDb{0}, peak{-100};
 double learnEnergy=0;int64_t learnCount=0;
 std::atomic<bool> resetLearn{false};
 CriticalSection previewLock;
 pm::Audio preview;
 double previewRate=44100,previewPos=0;
 bool playing=false;
 static AudioProcessorValueTreeState::ParameterLayout parameters(){
  AudioProcessorValueTreeState::ParameterLayout p;
  auto add=[&](const char* id,const char* label,float lo,float hi,float def){p.add(std::make_unique<AudioParameterFloat>(ParameterID{id,1},label,NormalisableRange<float>(lo,hi,.1f),def));};
  add("vocal","Vocal level",-12,12,0);add("warmth","Warmth",-6,6,0);add("brightness","Brightness",-6,6,0);
  add("space","Vocal space",0,100,12);add("target","Target active RMS",-22,-9,-14);add("drive","Master gain",-18,18,0);add("ceiling","Sample peak ceiling",-6,-1,-1.5f);
  return p;
 }
 float value(const char* id)const{return state.getRawParameterValue(id)->load();}
 PrinceProcessor():AudioProcessor(BusesProperties().withInput("Input",AudioChannelSet::stereo(),true).withOutput("Output",AudioChannelSet::stereo(),true)),state(*this,nullptr,"PrinceMix",parameters()){}
 const String getName()const override{return "PrinceMix";}
 bool acceptsMidi()const override{return false;}bool producesMidi()const override{return false;}bool isMidiEffect()const override{return false;}
 double getTailLengthSeconds()const override{return .003;}
 int getNumPrograms()override{return 1;}int getCurrentProgram()override{return 0;}void setCurrentProgram(int)override{}const String getProgramName(int)override{return {};}void changeProgramName(int,const String&)override{}
 bool isBusesLayoutSupported(const BusesLayout& b)const override {return b.getMainInputChannelSet()==b.getMainOutputChannelSet()&&(b.getMainOutputChannelSet()==AudioChannelSet::stereo()||b.getMainOutputChannelSet()==AudioChannelSet::mono());}
 void prepareToPlay(double sr,int)override{rate=sr;smoothDrive.reset(sr,.03);smoothDrive.setCurrentAndTargetValue(pm::gain(value("drive")));limiter.prepare(sr);setLatencySamples(limiter.latency());for(int c=0;c<2;++c){hp[c]={};body[c]={};air[c]={};hp[c].highpass(sr,25);}resetLearn=true;}
 void releaseResources()override{}
 void processBlock(AudioBuffer<float>& b,MidiBuffer&)override{
  ScopedNoDenormals noDenormals;
  if(resetLearn.exchange(false)){learnEnergy=0;learnCount=0;}
  for(int c=0;c<2;++c){body[c].peak(rate,250,.7,value("warmth"));air[c].peak(rate,4500,.65,value("brightness"));}
  smoothDrive.setTargetValue(pm::gain(value("drive")));
  float ceiling=pm::gain(value("ceiling")),p=0;
  const ScopedTryLock lock(previewLock);
  const bool previewing=lock.isLocked()&&playing&&!preview[0].empty();
  for(int i=0;i<b.getNumSamples();++i){
   float drive=smoothDrive.getNextValue();
   float l=b.getSample(0,i),r=b.getNumChannels()>1?b.getSample(1,i):l;
   if(!std::isfinite(l))l=0;
   if(!std::isfinite(r))r=0;
   if(learning.load()){
    if(std::max(std::abs(l),std::abs(r))>pm::gain(-60)){learnEnergy+=(l*l+r*r)*.5; ++learnCount;}
    if(learnCount>=int64_t(rate*10)){learnedDb=std::clamp(value("target")-pm::db((float)std::sqrt(learnEnergy/learnCount)),-18.f,18.f);learning=false;learned=true;}
   }
   auto y=limiter.tick(air[0].tick(body[0].tick(hp[0].tick(l)))*drive,air[1].tick(body[1].tick(hp[1].tick(r)))*drive,ceiling);
   if(previewing){
    size_t at=(size_t)previewPos;
    if(at<preview[0].size()){size_t next=std::min(at+1,preview[0].size()-1);float f=(float)(previewPos-at);for(int c=0;c<2;++c)y[c]=preview[c][at]*(1-f)+preview[c][next]*f;previewPos+=previewRate/rate;}
    else{y={0,0};playing=false;}
   }
   b.setSample(0,i,y[0]);if(b.getNumChannels()>1)b.setSample(1,i,y[1]);p=std::max(p,std::max(std::abs(y[0]),std::abs(y[1])));
  }
  peak=pm::db(p);
 }
 bool hasEditor()const override{return true;}AudioProcessorEditor* createEditor()override;
 void getStateInformation(MemoryBlock& dest)override{auto xml=state.copyState().createXml();copyXmlToBinary(*xml,dest);}
 void setStateInformation(const void* data,int size)override{if(auto xml=getXmlFromBinary(data,size))if(xml->hasTagName(state.state.getType()))state.replaceState(ValueTree::fromXml(*xml));}
};

struct StemRow:Component {
 Label name;ComboBox role;TextButton remove{"Remove"};File file;
 StemRow(File f):file(f){name.setText(f.getFileName(),dontSendNotification);role.addItemList({"Beat","Lead","Double","Harmony","Ad-lib"},1);role.setSelectedId(2);for(auto* c:std::initializer_list<Component*>{&name,&role,&remove})addAndMakeVisible(c);}
 void resized()override{auto r=getLocalBounds();remove.setBounds(r.removeFromRight(75));r.removeFromRight(8);role.setBounds(r.removeFromRight(110));name.setBounds(r);}
};
class PrinceEditor final:public AudioProcessorEditor,private Timer {
 PrinceProcessor& p;
 LookAndFeel_V4 look;
 Label heading,sub,status,meter;
 TextButton add{"Add stems"},renderButton{"Auto mix + master"},save{"Export WAVs"},play{"Preview master"},stop{"Stop"},learn{"Learn live master"};
 TextButton clear{"Clear stems"};
 OwnedArray<StemRow> rows;
 std::array<Slider,7> sliders;
 std::array<Label,7> labels;
 std::vector<std::unique_ptr<AudioProcessorValueTreeState::SliderAttachment>> attachments;
 std::unique_ptr<FileChooser> chooser;
 std::thread worker;
 std::atomic<bool> done{false},cancel{false};
 bool busy=false,ready=false;
 String failure,report;std::unique_ptr<pm::Result> result;double fileRate=44100;
 static pm::Audio readAudio(File f,AudioFormatManager& fm,double& sr){
  std::unique_ptr<AudioFormatReader> reader(fm.createReaderFor(f));
  if(!reader)throw std::runtime_error("Cannot read "+f.getFileName().toStdString()+". Use WAV or AIFF.");
  if(reader->numChannels<1||reader->numChannels>2)throw std::runtime_error("Only mono and stereo stems are supported.");
  if(reader->lengthInSamples<=0||reader->lengthInSamples>reader->sampleRate*600)throw std::runtime_error("Each stem must be between 1 sample and 10 minutes.");
  sr=reader->sampleRate;int n=(int)reader->lengthInSamples;AudioBuffer<float> buffer(2,n);buffer.clear();
  if(!reader->read(&buffer,0,n,0,true,true))throw std::runtime_error("Failed while reading audio.");
  if(reader->numChannels==1)buffer.copyFrom(1,0,buffer,0,0,n);
  auto a=pm::audio(n);for(int c=0;c<2;++c)std::copy_n(buffer.getReadPointer(c),n,a[c].begin());return a;
 }
 static void writeWav(File f,const pm::Audio& a,double sr){
  auto out=f.createOutputStream();if(!out)throw std::runtime_error("Cannot create output file.");
  WavAudioFormat fmt;std::unique_ptr<AudioFormatWriter> writer(fmt.createWriterFor(out.get(),sr,2,24,{},0));
  if(!writer)throw std::runtime_error("Cannot create WAV writer.");out.release();
  const float* channels[]={a[0].data(),a[1].data()};
  if(!writer->writeFromFloatArrays(channels,2,(int)a[0].size()))throw std::runtime_error("WAV write failed. Check disk space.");
 }
 void refresh(){add.setEnabled(!busy&&rows.size()<12);clear.setEnabled(!busy);renderButton.setEnabled(!busy&&rows.size()>0);save.setEnabled(!busy&&ready);play.setEnabled(!busy&&ready);for(auto* row:rows){row->remove.setEnabled(!busy);row->role.setEnabled(!busy);}for(auto& s:sliders)s.setEnabled(!busy);}
 void invalidate(){ready=false;const ScopedLock lock(p.previewLock);p.playing=false;p.preview={};refresh();}
 void startRender(){
  if(busy)return;if(worker.joinable())worker.join();invalidate();busy=true;refresh();status.setText("Processing your stems locally...",dontSendNotification);
  std::vector<std::pair<File,pm::Role>> files;for(auto* row:rows)files.emplace_back(row->file,(pm::Role)(row->role.getSelectedId()-1));
  pm::Settings settings{p.value("vocal"),p.value("warmth"),p.value("brightness"),p.value("space"),p.value("target"),p.value("ceiling")};
  done=false;cancel=false;failure={};
  worker=std::thread([this,files,settings]{try{
   AudioFormatManager fm;fm.registerBasicFormats();std::vector<pm::Stem> stems;double common=0;size_t total=0;
   for(auto& item:files){if(cancel)return;double sr=0;auto a=readAudio(item.first,fm,sr);if(common&&std::abs(sr-common)>.1)throw std::runtime_error("Stems have different sample rates. Export all stems at the same rate from Audition.");common=sr;total+=a[0].size();if(total>size_t(48000)*60*30)throw std::runtime_error("Session is too large. Use fewer stems or shorter sections (30 total stem-minutes at 48 kHz).");stems.push_back({std::move(a),item.second,item.first.getFileName().toStdString()});}
   if(cancel)return;
   result=std::make_unique<pm::Result>(pm::render(stems,common,settings));fileRate=common;
   report="PRINCEMIX 0.1 PROCESSING REPORT\nSample rate: "+String(common,0)+" Hz\nTarget active RMS: "+String(settings.targetRms,1)+" dBFS (not LUFS)\n";
   for(auto& st:result->stems)report+=String(st.name)+" ["+pm::roleName(st.role)+"] input active RMS "+String(st.inputDb,1)+" dBFS; net level change before shared mix headroom "+String(st.adjustDb,1)+" dB\n";
   report+="Mix RMS: "+String(result->mixMeter.rmsDb,1)+" dBFS\nMaster RMS: "+String(result->masterMeter.rmsDb,1)+" dBFS\nMaster active RMS: "+String(result->masterMeter.activeDb,1)+" dBFS\nMaster sample peak: "+String(result->masterMeter.peakDb,1)+" dBFS\nMaster gain requested: "+String(result->masterGain,1)+" dB\nLimiter may prevent reaching target. Sample peak limiting is not true-peak limiting.\n";
  }catch(const std::exception& e){failure=e.what();result.reset();}done=true;});
 }
 void timerCallback()override{
  meter.setText("OUTPUT  "+String(p.peak.load(),1)+" dBFS",dontSendNotification);
  if(p.learned.exchange(false)){auto* param=p.state.getParameter("drive");param->beginChangeGesture();param->setValueNotifyingHost(param->convertTo0to1(p.learnedDb));param->endChangeGesture();learn.setButtonText("Learn live master");status.setText("Master gain learned. Listen and adjust before exporting.",dontSendNotification);}
  if(done.exchange(false)){if(worker.joinable())worker.join();busy=false;ready=(result!=nullptr);if(ready)status.setText("Ready. Master RMS "+String(result->masterMeter.rmsDb,1)+" dBFS | Sample peak "+String(result->masterMeter.peakDb,1)+" dBFS",dontSendNotification);else status.setText(failure,dontSendNotification);refresh();}
 }
public:
 PrinceEditor(PrinceProcessor& proc):AudioProcessorEditor(proc),p(proc){
  look.setColour(ResizableWindow::backgroundColourId,Colour(0xff11151d));look.setColour(Slider::thumbColourId,Colour(0xffa9f75d));look.setColour(Slider::rotarySliderFillColourId,Colour(0xffa9f75d));look.setColour(TextButton::buttonColourId,Colour(0xff273241));look.setColour(TextButton::textColourOffId,Colours::white);setLookAndFeel(&look);
  heading.setText("PRINCEMIX",dontSendNotification);heading.setFont(Font(FontOptions(32.f,Font::bold)));sub.setText("AUTO MIX / MASTER     •     PRINCE CITY AUDIO     •     0.1 ALPHA",dontSendNotification);
  status.setText("Add aligned stems exported from the same timeline start. Choose each role.",dontSendNotification);status.setColour(Label::textColourId,Colour(0xffa9f75d));
  for(auto* c:std::initializer_list<Component*>{&heading,&sub,&status,&meter,&add,&renderButton,&save,&play,&stop,&learn,&clear})addAndMakeVisible(c);
  const char* ids[]={"vocal","warmth","brightness","space","target","drive","ceiling"};const char* names[]={"VOCAL dB","WARMTH dB","BRIGHTNESS dB","SPACE %","TARGET RMS","LIVE GAIN dB","CEILING dBFS"};
  for(size_t i=0;i<7;++i){labels[i].setText(names[i],dontSendNotification);labels[i].setJustificationType(Justification::centred);addAndMakeVisible(labels[i]);sliders[i].setSliderStyle(Slider::RotaryHorizontalVerticalDrag);sliders[i].setTextBoxStyle(Slider::TextBoxBelow,false,85,22);addAndMakeVisible(sliders[i]);attachments.push_back(std::make_unique<AudioProcessorValueTreeState::SliderAttachment>(p.state,ids[i],sliders[i]));sliders[i].onDragEnd=[this,i]{if(i!=5){invalidate();status.setText("Settings changed. Run Auto mix + master to refresh the stem render.",dontSendNotification);}};}
  add.onClick=[this]{chooser=std::make_unique<FileChooser>("Choose aligned WAV or AIFF stems",File{},"*.wav;*.aif;*.aiff");chooser->launchAsync(FileBrowserComponent::openMode|FileBrowserComponent::canSelectFiles|FileBrowserComponent::canSelectMultipleItems,[safe=Component::SafePointer<PrinceEditor>(this)](const FileChooser& fc){if(!safe)return;auto& e=*safe;for(auto& f:fc.getResults()){if(e.rows.size()>=12)break;auto* row=e.rows.add(new StemRow(f));if(e.rows.size()==1)row->role.setSelectedId(1);e.addAndMakeVisible(row);row->role.onChange=[safe]{if(safe)safe->invalidate();};row->remove.onClick=[safe,row]{if(!safe)return;MessageManager::callAsync([safe,row]{if(safe){safe->rows.removeObject(row);safe->invalidate();safe->resized();}});};}e.invalidate();e.resized();});};
  clear.onClick=[this]{rows.clear();invalidate();resized();};renderButton.onClick=[this]{startRender();};
  learn.onClick=[this]{bool start=!p.learning.load();p.resetLearn=true;p.learning=start;learn.setButtonText(start?"Cancel learning":"Learn live master");status.setText(start?"Play at least 10 seconds of audible song audio in Audition. Learning level...":"Learning cancelled.",dontSendNotification);};
  play.onClick=[this]{if(!result)return;if(std::abs(fileRate-p.rate)>.1){status.setText("For preview, set the host/audio device to the stems sample rate. WAV export is still available.",dontSendNotification);return;}const ScopedLock lock(p.previewLock);p.preview=result->master;p.previewRate=fileRate;p.previewPos=0;p.playing=true;status.setText("Preview replaces the plugin output. Host audio must be running. Stop before exporting your Audition session.",dontSendNotification);};
  stop.onClick=[this]{const ScopedLock lock(p.previewLock);p.playing=false;};
  save.onClick=[this]{chooser=std::make_unique<FileChooser>("Choose export folder",File::getSpecialLocation(File::userDocumentsDirectory));chooser->launchAsync(FileBrowserComponent::openMode|FileBrowserComponent::canSelectDirectories,[safe=Component::SafePointer<PrinceEditor>(this)](const FileChooser& fc){if(!safe||!safe->result)return;auto folder=fc.getResult();if(!folder.isDirectory())return;try{auto destination=folder.getNonexistentChildFile("PrinceMix-"+Time::getCurrentTime().formatted("%Y%m%d-%H%M%S"),"",false);if(destination.createDirectory().failed())throw std::runtime_error("Cannot create export folder.");writeWav(destination.getChildFile("Mix.wav"),safe->result->mix,safe->fileRate);writeWav(destination.getChildFile("Master.wav"),safe->result->master,safe->fileRate);if(!destination.getChildFile("Processing-report.txt").replaceWithText(safe->report))throw std::runtime_error("Could not write report.");safe->status.setText("Exported Mix.wav, Master.wav, and processing report to "+destination.getFullPathName(),dontSendNotification);}catch(const std::exception& ex){safe->status.setText(String("Export failed: ")+ex.what(),dontSendNotification);}});};
  setSize(940,800);refresh();startTimerHz(10);
 }
 ~PrinceEditor()override{stopTimer();p.learning=false;cancel=true;if(worker.joinable())worker.join();{const ScopedLock lock(p.previewLock);p.playing=false;p.preview={};}setLookAndFeel(nullptr);}
 void paint(Graphics& g)override{
  g.fillAll(Colour(0xff11151d));g.setColour(Colour(0xff1b2330));g.fillRoundedRectangle(18,98,(float)getWidth()-36,168,12);g.fillRoundedRectangle(18,292,(float)getWidth()-36,370,12);
  g.setColour(Colour(0xff9daabd));g.setFont(13.f);g.drawText("STEM MIXER  /  WAV + AIFF  /  UP TO 12 STEMS",30,277,600,20,Justification::left);
  g.drawText("LIVE MASTER: Warmth + Brightness + Live Gain + Ceiling. Vocal, Space, and Target guide stem renders.",28,710,890,20,Justification::left);
  g.drawText("Level-based assistant. RMS is not LUFS. No stem separation or automatic session fader control.",28,733,890,20,Justification::left);
 }
 void resized()override{
  heading.setBounds(28,18,400,40);sub.setBounds(30,61,700,22);meter.setBounds(720,28,190,28);
  for(int i=0;i<7;++i){int x=25+i*127;labels[(size_t)i].setBounds(x,110,125,22);sliders[(size_t)i].setBounds(x,134,125,121);}
  for(int i=0;i<rows.size();++i)rows[i]->setBounds(30,304+i*29,880,25);
  add.setBounds(30,674,120,30);clear.setBounds(158,674,110,30);renderButton.setBounds(277,674,190,30);play.setBounds(477,674,145,30);stop.setBounds(631,674,60,30);save.setBounds(700,674,105,30);learn.setBounds(720,58,190,30);status.setBounds(25,758,890,36);
 }
};
AudioProcessorEditor* PrinceProcessor::createEditor(){return new PrinceEditor(*this);}
AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new PrinceProcessor();}
