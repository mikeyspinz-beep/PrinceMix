#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <vector>
#include <stdexcept>
#include <string>
#include <limits>
#include <cstdint>

namespace pm {
constexpr double pi=3.14159265358979323846;
inline float gain(float db) { return std::pow(10.0f,db/20.0f); }
inline float db(float x) { return 20.0f*std::log10(std::max(x,1.0e-9f)); }
using Audio=std::array<std::vector<float>,2>;
inline Audio audio(size_t n) { return {std::vector<float>(n),std::vector<float>(n)}; }
struct Biquad {
 double b0=1,b1=0,b2=0,a1=0,a2=0,z1=0,z2=0;
 void highpass(double rate,double freq) {
  double w=2*pi*freq/rate,c=cos(w),s=sin(w),a=s/(2*0.70710678),n=1+a;
  b0=(1+c)/2/n;b1=-(1+c)/n;b2=b0;a1=-2*c/n;a2=(1-a)/n;
 }
 void peak(double rate,double freq,double q,double amount) {
  double A=pow(10,amount/40),w=2*pi*freq/rate,c=cos(w),a=sin(w)/(2*q),n=1+a/A;
  b0=(1+a*A)/n;b1=-2*c/n;b2=(1-a*A)/n;a1=b1;a2=(1-a/A)/n;
 }
 float tick(float x) { double y=b0*x+z1; z1=b1*x-a1*y+z2; z2=b2*x-a2*y; return (float)y; }
};
struct Meter { float rmsDb=-180,peakDb=-180,activeDb=-180; };
inline Meter measure(const Audio& a) {
 if(a[0].empty() || a[0].size()!=a[1].size()) return {};
 double sum=0;float peak=0;std::vector<double> blocks;
 constexpr size_t block=2048;
 for(size_t i=0;i<a[0].size();i+=block) {
  double e=0;size_t n=std::min(block,a[0].size()-i);
  for(size_t j=i;j<i+n;++j) for(int c=0;c<2;++c) {double x=a[c][j];e+=x*x;peak=std::max(peak,(float)std::abs(x));}
  blocks.push_back(e/(2*n));sum+=e;
 }
 double overall=sum/(2*a[0].size()),active=0;size_t count=0;
 for(auto e:blocks) if(e>std::max(1.0e-8,overall*0.1)) {active+=e;++count;}
 return {db((float)sqrt(overall)),db(peak),db((float)sqrt(count?active/count:0))};
}
struct Compressor {
 float env=0,g=1,attack=0,release=0,threshold=-20,ratio=3;
 void prepare(double sr,float atkMs,float relMs,float th,float r) {
  env=0;g=1;attack=std::exp(-1.0f/(float(sr)*atkMs*.001f));release=std::exp(-1.0f/(float(sr)*relMs*.001f));threshold=th;ratio=r;
 }
 float reduction(float level) {
  float coeff=level>env?attack:release;env=coeff*env+(1-coeff)*level;
  float over=std::max(0.0f,db(env)-threshold);return gain(-over*(1-1/ratio));
 }
};
// Stereo-linked lookahead limiter. Gain reduction is immediate; recovery is smoothed.
// The delayed signal and peak window have identical length. Output has latency().
class Limiter {
 std::vector<std::array<float,2>> delay;
 std::vector<float> peaks;
 std::vector<uint64_t> indices;
 size_t head=0,tail=0,used=0;uint64_t clock=0;
 size_t pos=0;float g=1,release=0;int count=0;
 public:
 void prepare(double sr) {count=std::max(1,(int)std::round(sr*.003));delay.assign(count+1,{0,0});peaks.assign(count+2,0);indices.assign(count+2,0);head=tail=used=0;clock=0;pos=0;g=1;release=std::exp(-1.0f/(float(sr)*.080f));}
 int latency() const { return count; }
 std::array<float,2> tick(float l,float r,float ceiling) {
  if(!std::isfinite(l))l=0;
  if(!std::isfinite(r))r=0;
  delay[pos]={l,r};float current=std::max(std::abs(l),std::abs(r));
  const size_t capacity=peaks.size();
  while(used && indices[head]+(uint64_t)count<clock){head=(head+1)%capacity;--used;}
  while(used){size_t last=(tail+capacity-1)%capacity;if(peaks[last]>current)break;tail=last;--used;}
  peaks[tail]=current;indices[tail]=clock++;tail=(tail+1)%capacity;++used;
  float p=peaks[head];float target=p>ceiling?ceiling/p:1;
  g=target<g?target:release*g+(1-release)*target;
  size_t out=(pos+1)%delay.size();auto y=delay[out];pos=out;
  for(auto& x:y)x=std::clamp(x*g,-ceiling,ceiling);
  return y;
 }
};
struct Settings {float vocal=0,warmth=0,brightness=0,space=12,targetRms=-14,ceiling=-1.5f;};
enum class Role {Beat,Lead,Double,Harmony,Adlib};
inline const char* roleName(Role r) {switch(r){case Role::Beat:return "Beat";case Role::Lead:return "Lead";case Role::Double:return "Double";case Role::Harmony:return "Harmony";default:return "Ad-lib";}}
struct Stem {Audio samples;Role role=Role::Lead;std::string name;};
struct StemReport {std::string name;Role role;float inputDb,adjustDb;};
struct Result {Audio mix,master;Meter mixMeter,masterMeter;std::vector<StemReport> stems;float masterGain=0;};
inline void validate(const Audio& a) {
 if(a[0].empty()||a[0].size()!=a[1].size())throw std::runtime_error("Empty or mismatched audio channels.");
 for(auto& c:a)for(auto x:c)if(!std::isfinite(x))throw std::runtime_error("Audio contains non-finite samples.");
}
inline void vocalProcess(Audio& a,double sr,const Settings& s) {
 std::array<Biquad,2> hp,body,air,ess;
 for(int c=0;c<2;++c){hp[c].highpass(sr,85);body[c].peak(sr,250,.7,s.warmth-2);air[c].peak(sr,4500,.65,s.brightness);ess[c].highpass(sr,5500);}
 Compressor comp,deess;comp.prepare(sr,8,100,-20,3);deess.prepare(sr,1,60,-28,4);
 for(size_t i=0;i<a[0].size();++i){
  float x[2],hi[2];for(int c=0;c<2;++c){x[c]=air[c].tick(body[c].tick(hp[c].tick(a[c][i])));hi[c]=ess[c].tick(x[c]);}
  float dg=std::max(.35f,deess.reduction(std::max(std::abs(hi[0]),std::abs(hi[1]))));
  float cg=comp.reduction(std::max(std::abs(x[0]),std::abs(x[1])));
  for(int c=0;c<2;++c)a[c][i]=(x[c]-(1-dg)*hi[c])*cg;
 }
 // Subtle two-tap ambience, no tempo claim. Padding supplied by renderer.
 float wet=s.space/100.0f*.3f;
 for(int c=0;c<2;++c){size_t d=(size_t)(sr*(c==0?.071:.097));for(size_t i=a[c].size();i-->d;)a[c][i]+=a[c][i-d]*wet;}
}
inline Result render(const std::vector<Stem>& stems,double sr,const Settings& s) {
 if(stems.empty())throw std::runtime_error("Load at least one stem.");
 if(sr<22050||sr>192000)throw std::runtime_error("Use a sample rate between 22050 and 192000 Hz.");
 size_t n=0;int leads=0,backings=0;
 for(auto& st:stems){validate(st.samples);n=std::max(n,st.samples[0].size());if(st.role==Role::Lead)++leads;else if(st.role!=Role::Beat)++backings;}
 n+=(size_t)(sr*.25);Result result;result.mix=audio(n);
 for(auto& st:stems){
  Audio a=st.samples;auto before=measure(a);
  if(st.role!=Role::Beat){
   float pre=std::clamp(-22-before.activeDb,-24.f,18.f);
   for(auto& ch:a)for(auto& x:ch)x*=gain(pre);
   for(auto& ch:a)ch.resize(n);
   vocalProcess(a,sr,s);
  }
  auto m=measure(a);float target=-19;
  if(st.role==Role::Lead)target=-22+s.vocal-10*std::log10((float)std::max(1,leads));
  if(st.role==Role::Double)target=-29+s.vocal;
  if(st.role==Role::Harmony)target=-27+s.vocal;
  if(st.role==Role::Adlib)target=-30+s.vocal;
  if(st.role!=Role::Beat&&st.role!=Role::Lead)target-=10*std::log10((float)std::max(1,backings));
  float adjust=m.activeDb<-75?0:std::clamp(target-m.activeDb,-30.f,18.f);
  for(int c=0;c<2;++c)for(size_t i=0;i<a[c].size();++i)result.mix[c][i]+=a[c][i]*gain(adjust);
  result.stems.push_back({st.name,st.role,before.activeDb,m.activeDb+adjust-before.activeDb});
 }
 result.mixMeter=measure(result.mix);
 // Guarantee headroom in the unmastered output.
 if(result.mixMeter.peakDb>-6){float g=gain(-6-result.mixMeter.peakDb);for(auto& c:result.mix)for(auto& x:c)x*=g;result.mixMeter=measure(result.mix);}
 result.masterGain=result.mixMeter.activeDb<-75?0:std::clamp(s.targetRms-result.mixMeter.activeDb,-18.f,18.f);
 Limiter limiter;limiter.prepare(sr);result.master=audio(n);size_t latency=(size_t)limiter.latency();
 for(size_t i=0;i<n+latency;++i){auto y=limiter.tick(i<n?result.mix[0][i]*gain(result.masterGain):0,i<n?result.mix[1][i]*gain(result.masterGain):0,gain(s.ceiling));if(i>=latency){result.master[0][i-latency]=y[0];result.master[1][i-latency]=y[1];}}
 result.masterMeter=measure(result.master);return result;
}
} // namespace pm
