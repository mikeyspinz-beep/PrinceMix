#include "../Source/Engine.h"
#include <iostream>
#include <random>
#include <cstdlib>
void require(bool ok,const char* why){if(!ok){std::cerr<<"FAIL: "<<why<<"\n";std::exit(1);}}
pm::Audio tone(double sr,int seconds,float amplitude,double freq){auto a=pm::audio((size_t)(sr*seconds));for(size_t i=0;i<a[0].size();++i)a[0][i]=a[1][i]=amplitude*(float)std::sin(2*pm::pi*freq*i/sr);return a;}
int main(){
 for(double sr:{22050.,44100.,48000.,96000.,192000.}){
  pm::Limiter l;l.prepare(sr);float ceiling=pm::gain(-1.5);std::mt19937 gen(42);std::uniform_real_distribution<float>d(-12,12);
  for(int i=0;i<100000;++i){auto y=l.tick(d(gen),d(gen),ceiling);require(std::isfinite(y[0])&&std::isfinite(y[1]),"limiter finite");require(std::abs(y[0])<=ceiling+.000001&&std::abs(y[1])<=ceiling+.000001,"limiter ceiling");}
  l.prepare(sr);int latency=l.latency();for(int i=0;i<latency+2;++i){auto y=l.tick(i==0?.25f:0,i==0?.25f:0,ceiling);require(std::abs(y[0]-(i==latency?.25f:0))<.000001,"latency exact");}
 }
 auto beat=tone(48000,2,.8,80);auto vocal=tone(48000,2,.05,600);
 std::vector<pm::Stem> stems{{beat,pm::Role::Beat,"beat"},{vocal,pm::Role::Lead,"lead"}};
 auto r=pm::render(stems,48000,{});require(r.master[0].size()==108000,"render length and tail");require(r.masterMeter.peakDb<=-1.499,"master ceiling");require(r.mixMeter.peakDb<=-5.999,"mix headroom");require(r.stems.size()==2,"report tracks");require(r.masterMeter.rmsDb>r.mixMeter.rmsDb,"master increases level");
 auto silence=pm::render({{pm::audio(48000),pm::Role::Lead,"silence"}},48000,{});for(auto x:silence.master[0])require(x==0,"silence stays silent");
 auto impulse=pm::audio(48000);impulse[0][0]=impulse[1][0]=.5;auto ir=pm::render({{impulse,pm::Role::Beat,"impulse"}},48000,{});require(ir.master[0][0]>0,"offline latency compensated");
 auto broken=vocal;broken[0][10]=std::numeric_limits<float>::quiet_NaN();bool threw=false;try{pm::render({{broken,pm::Role::Lead,"broken"}},48000,{});}catch(...){threw=true;}require(threw,"invalid sample rejection");
 threw=false;try{pm::render({},48000,{});}catch(...){threw=true;}require(threw,"empty session rejection");
 pm::Settings quiet;quiet.vocal=-12;auto q=pm::render(stems,48000,quiet);require(q.stems[1].adjustDb<r.stems[1].adjustDb-11.9,"vocal adjustment");
 std::cout<<"PASS: ceiling and latency at five sample rates, render length, headroom, master gain, silence, impulse alignment, invalid inputs, vocal adjustment\n";
}
