# Verification — 2026-10-15

Completed in a Linux build environment:

- CMake configure/build of dependency-free engine test executable.
- CTest: 1 suite passed, 0 failures.
- Limiter sample-peak ceiling and exact latency tested at 22.05, 44.1, 48, 96, and 192 kHz with randomized high-amplitude input.
- Offline output length, ambience padding, -6 dBFS mix headroom, master gain, silence preservation, first-sample impulse alignment, invalid-input rejection, and vocal adjustment checked.
- Plugin.cpp passed C++17 compiler syntax checking against the pinned JUCE 8.0.6 headers.
- Mac build script passed Bash syntax checking.
- Engine tests passed AddressSanitizer and UndefinedBehaviorSanitizer with leak detection disabled (LeakSanitizer cannot inspect processes in this container).

Not verified:

- Full native plugin link/build on macOS or Windows.
- Loading/scanning in Adobe Audition, host parameter recall, native UI interaction, preview playback, or WAV export through the GUI.
- Real-recording listening quality, CPU performance inside Audition, or true-peak compliance.

This archive contains source, tests, instructions, and build scripts. It does not contain a prebuilt VST3, AU, or standalone application binary.
