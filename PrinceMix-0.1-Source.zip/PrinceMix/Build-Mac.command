#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
trap 'echo; echo "Build stopped. Copy the error above if you need help."; read -r -p "Press Return to close..."' ERR
if ! xcode-select -p >/dev/null 2>&1; then
 echo 'Install Apple Command Line Tools first by running: xcode-select --install'
 exit 1
fi
if command -v cmake >/dev/null 2>&1; then
 PM_CMAKE="$(command -v cmake)"
elif [ -x /Applications/CMake.app/Contents/bin/cmake ]; then
 PM_CMAKE=/Applications/CMake.app/Contents/bin/cmake
else
 echo 'Install the macOS CMake application from https://cmake.org/download/ into Applications, then run this again.'
 read -r -p 'Press Return to close...'
 exit 1
fi
printf '\nBuilding PrinceMix 0.1 for this Mac. First run downloads JUCE 8.0.6.\n'
"$PM_CMAKE" -S . -B build-mac -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_DEPLOYMENT_TARGET=11.0
"$PM_CMAKE" --build build-mac --config Release --parallel 2
"$PM_CMAKE" --build build-mac --config Release --target engine_tests
./build-mac/engine_tests
PM_OUTPUT="$PWD/build-mac/PrinceMix_artefacts/Release"
PM_STAMP="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$HOME/Library/Audio/Plug-Ins/VST3" "$HOME/Library/Audio/Plug-Ins/Components"
for PM_PAIR in 'VST3|PrinceMix.vst3|VST3' 'AU|PrinceMix.component|Components'; do
 IFS='|' read -r PM_FORMAT PM_NAME PM_DEST <<< "$PM_PAIR"
 PM_SOURCE="$PM_OUTPUT/$PM_FORMAT/$PM_NAME"
 PM_TARGET="$HOME/Library/Audio/Plug-Ins/$PM_DEST/$PM_NAME"
 if [ ! -d "$PM_SOURCE" ]; then echo "Missing build product: $PM_SOURCE"; exit 1; fi
 codesign --force --deep --sign - "$PM_SOURCE"
 if [ -e "$PM_TARGET" ]; then
  mkdir -p "$HOME/Library/Application Support/PrinceMix/Backups/$PM_STAMP"
  mv "$PM_TARGET" "$HOME/Library/Application Support/PrinceMix/Backups/$PM_STAMP/$PM_NAME"
 fi
 ditto "$PM_SOURCE" "$PM_TARGET"
done
printf '\nInstalled PrinceMix VST3 and Audio Unit.\nRestart Audition, open Effects > Audio Plug-In Manager, and scan for plugins.\nStandalone app: %s/Standalone/PrinceMix.app\n' "$PM_OUTPUT"
open "$PM_OUTPUT"
read -r -p 'Press Return to close...'
